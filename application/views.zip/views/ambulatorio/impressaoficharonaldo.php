<?
$i = 0;
$b = 0;
$total = count($exame);
foreach ($exame as $value) :
    $i++;
    $b++;
    ?>

    <? if ($i == 1) {
        ?>
        <hr align="left" width="850" size="1" color=red>
        <p>
            <?
        }
        ?>

    <table border="1">
        <tbody>
            <tr>
                <td width="250px;"><img align = 'left'  width='160px' height='50px' src=<?= base_url() . "img/LOGO.jpg" ?>></td> 
                <td colspan="2" width="400px;"><img align = 'left'  width='160px' height='50px' src=<?= base_url() . "img/LOGO.jpg" ?>> &nbsp;&nbsp;<b>TAXA DE ADMINISTRA&Ccedil;&Atilde;O</b></td> 
                <td width="200px;">Valor R$: <p><font size = 6><b>&nbsp;&nbsp;&nbsp;&nbsp;<?= number_format($value->valor, 2, ',', '.'); ?></b></font></td>        
            </tr>
            <tr>
                <td >BENEFIC&Aacute;RIO: <P><b><?= $value->paciente; ?></b></td>
                <td colspan="2" >BENEFIC&Aacute;RIO: <b><?= $value->paciente; ?></b></td>
                <td >PLANO:<b> <?= utf8_decode($value->plano) ?></b></td>
            </tr>
            <tr>
                <td >ENDERE&Ccedil;O:<p><font size = -2><b><?= substr(utf8_decode($value->logradouro), 0, 20) . "  " . $value->numero . " - " . utf8_decode($value->bairro)  . " - " . $value->municipio ?></b></font></td>
                <td colspan="3">ENDERE&Ccedil;O:&nbsp;&nbsp;<b> <?= utf8_decode($value->logradouro) . "  " . $value->numero . " - " . utf8_decode($value->bairro)  . " - " . $value->municipio ?></b></td>
            </tr>
            <tr>
                <td >DOCUMENTO:  PARC <b><?= $value->parcela . " / " . $total ?></b></td>
                <td colspan="3">CONTATOS &nbsp;&nbsp; <b><?= "(" . substr($value->telefone, 0, 2) . ")". substr($value->telefone, 3, 4) . ".". substr($value->telefone, 7, 4);?></b></td>
            </tr>

            <tr>
                <td >Valor: <b><?= number_format($value->valor, 2, ',', '.'); ?></b></td>
                <td colspan="3">DOCUMENTO:  PARC <b><?= $value->parcela . " / " . $total ?></b>&nbsp;&nbsp;&nbsp; VALOR: <b><?= number_format($value->valor, 2, ',', '.'); ?></b> &nbsp;&nbsp;&nbsp;VENCIMENTO: <b><?= substr($value->data, 8, 2) . "/" . substr($value->data, 5, 2) . "/" . substr($value->data, 0, 4); ?></b></td>
            </tr>

            <tr><td >Vencimento:<b><?= substr($value->data, 8, 2) . "/" . substr($value->data, 5, 2) . "/" . substr($value->data, 0, 4); ?></b><br>  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;<font size = -3><b>VIA DO CLIENTE</b></font></td>
                <td colspan="3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<u>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</u><br><font size = -3><b>VIA DO ESTABELECIMENTO</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;ASSINATURA DO BENEFICI&Aacute;RIO</font></td>
            </tr>
        </tbody>
    </table>
    <p>
    <hr align="left" width="850" size="1" color=red>
    <p>
        <? if ($i == 3 && $b < $total) {
            ?>
            <br style="page-break-before: always;" />
            <?
            $i = 0;
        }
        ?>
    <? endforeach; ?>
    <script type="text/javascript">
        window.print()


    </script>