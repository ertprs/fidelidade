
            </div>
        </section>

        <script>var BASE_URL = '<?= base_url(); ?>';</script>
        <?php flashmessages_to_html(); ?>
        <?php show_javascripts(); ?>

    </body>
</html>
