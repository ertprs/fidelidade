<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
    <HEAD>
        <META HTTP-EQUIV="CONTENT-TYPE" CONTENT="text/html; charset=utf-8">
        <TITLE></TITLE>
        <META NAME="GENERATOR" CONTENT="LibreOffice 3.5  (Linux)">
        <META NAME="CREATED" CONTENT="20160928;17140800">
        <META NAME="CHANGED" CONTENT="20160928;17584400">
        <STYLE TYPE="text/css">
            <!--
            @page { margin: 2cm }
            P { margin-bottom: 0.21cm }
            P.western { so-language: pt-BR }
            TD P { margin-bottom: 0cm }
            TD P.western { so-language: pt-BR }
            A:link { so-language: zxx }
            A:visited { so-language: zxx }
            -->
        </STYLE>
    </HEAD>
    <BODY LANG="pt-BR" DIR="LTR">
        <P CLASS="western" ALIGN=left STYLE="margin-bottom: 0cm"><A NAME="__DdeLink__3_1833116309"></A>
            <B><FONT SIZE=2>FOLHA DE GASTOS</FONT></B></P>
        <TABLE WIDTH=789 CELLPADDING=4 CELLSPACING=0><CENTER>
                <COL WIDTH=120>
                <COL WIDTH=41>
                <COL WIDTH=124>
                <COL WIDTH=42>
                <COL WIDTH=111>
                <COL WIDTH=38>
                <COL WIDTH=255>
                <TR VALIGN=TOP>
                    <TD WIDTH=120 HEIGHT=5 STYLE="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0.1cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1><B>Material</B></FONT></P>
                    </TD>
                    <TD WIDTH=41 STYLE="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0.1cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1><B>Qtde</B></FONT></P>
                    </TD>
                    <TD WIDTH=124 STYLE="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0.1cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1><B>Material</B></FONT></P>
                    </TD>
                    <TD WIDTH=42 STYLE="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0.1cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1><B>Qtde</B></FONT></P>
                    </TD>
                    <TD WIDTH=111 STYLE="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0.1cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1><B>Material</B></FONT></P>
                    </TD>
                    <TD WIDTH=38 STYLE="border-top: 1px solid #000000; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0.1cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1><B>Qtde</B></FONT></P>
                    </TD>
                    <TD ROWSPAN=4 WIDTH=255 STYLE="border: 1px solid #000000; padding: 0.1cm">
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>Contraste: Sim (  )    
                                Não(  )</FONT></P>
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>Dose:_____ml</FONT></P>
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>Qual
                                Contraste___________</FONT></P>
                        <P CLASS="western" ALIGN=LEFT><BR>
                        </P>
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>Lote:_________________</FONT></P>
                    </TD>
                </TR>
                <TR VALIGN=TOP>
                    <TD WIDTH=120 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>Scalp n°</FONT></P>
                    </TD>
                    <TD WIDTH=41 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><BR>
                        </P>
                    </TD>
                    <TD WIDTH=124 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>Contraste</FONT></P>
                    </TD>
                    <TD WIDTH=42 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><BR>
                        </P>
                    </TD>
                    <TD WIDTH=111 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>Soro Ringer</FONT></P>
                    </TD>
                    <TD WIDTH=38 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><BR>
                        </P>
                    </TD>
                </TR>
                <TR VALIGN=TOP>
                    <TD WIDTH=120 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>Seringa  ml</FONT></P>
                    </TD>
                    <TD WIDTH=41 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><BR>
                        </P>
                    </TD>
                    <TD WIDTH=124 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>Equipo n°</FONT></P>
                    </TD>
                    <TD WIDTH=42 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><BR>
                        </P>
                    </TD>
                    <TD WIDTH=111 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>Água</FONT></P>
                    </TD>
                    <TD WIDTH=38 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><BR>
                        </P>
                    </TD>
                </TR>
                <TR VALIGN=TOP>
                    <TD WIDTH=120 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>Abocat   n°</FONT></P>
                    </TD>
                    <TD WIDTH=41 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><BR>
                        </P>
                    </TD>
                    <TD WIDTH=124 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>Esparadrapo</FONT></P>
                    </TD>
                    <TD WIDTH=42 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><BR>
                        </P>
                    </TD>
                    <TD WIDTH=111 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>Luva</FONT></P>
                    </TD>
                    <TD WIDTH=38 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><BR>
                        </P>
                    </TD>
                </TR>
                <TR VALIGN=TOP>
                    <TD WIDTH=120 HEIGHT=5 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>Agulha n°</FONT></P>
                    </TD>
                    <TD WIDTH=41 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><BR>
                        </P>
                    </TD>
                    <TD WIDTH=124 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>Alcool</FONT></P>
                    </TD>
                    <TD WIDTH=42 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><BR>
                        </P>
                    </TD>
                    <TD WIDTH=111 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>Filmes</FONT></P>
                    </TD>
                    <TD WIDTH=38 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><BR>
                        </P>
                    </TD>
                    <TD ROWSPAN=3 WIDTH=255 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0.1cm">
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>Exame finalizado:</FONT></P>
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>com intercorrencia  (  
                                ) </FONT>
                        </P>
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>sem intercorrencia (  )
                            </FONT>
                        </P>
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>Justificativa:</FONT></P>
                    </TD>
                </TR>
                <TR VALIGN=TOP>
                    <TD WIDTH=120 HEIGHT=5 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>Bolas de Algodão</FONT></P>
                    </TD>
                    <TD WIDTH=41 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><BR>
                        </P>
                    </TD>
                    <TD WIDTH=124 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>Soro Físico    ml</FONT></P>
                    </TD>
                    <TD WIDTH=42 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><BR>
                        </P>
                    </TD>
                    <TD WIDTH=111 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>Filmes papel</FONT></P>
                    </TD>
                    <TD WIDTH=38 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><BR>
                        </P>
                    </TD>
                </TR>
                <TR VALIGN=TOP>
                    <TD WIDTH=120 HEIGHT=5 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>Compressa Gaze</FONT></P>
                    </TD>
                    <TD WIDTH=41 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><BR>
                        </P>
                    </TD>
                    <TD WIDTH=124 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>Soro Glico     ml</FONT></P>
                    </TD>
                    <TD WIDTH=42 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><BR>
                        </P>
                    </TD>
                    <TD WIDTH=111 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>CD/DVD</FONT></P>
                    </TD>
                    <TD WIDTH=38 STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: none; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0cm">
                        <P CLASS="western" ALIGN=LEFT><BR>
                        </P>
                    </TD>
                </TR>
                <TR>
                    <TD COLSPAN=7 WIDTH=779 HEIGHT=25 VALIGN=TOP STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0.1cm">
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>Anotações de
                                Enfermagem:</FONT></P>
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>P.A PRÉ -</FONT></P>
                        <P CLASS="western" ALIGN=LEFT><FONT SIZE=1>P.A PÓS -</FONT></P>
                    </TD>
                </TR>
        </TABLE>
        <TABLE WIDTH=789 CELLPADDING=4 CELLSPACING=0>
            <COL WIDTH=779>
	<TR>
		<TD WIDTH=779 HEIGHT=31 VALIGN=TOP STYLE="border-top: none; border-bottom: 1px solid #000000; border-left: 1px solid #000000; border-right: 1px solid #000000; padding-top: 0cm; padding-bottom: 0.1cm; padding-left: 0.1cm; padding-right: 0.1cm">
			<P CLASS="western"><FONT FACE="Serif"><FONT SIZE=1 STYLE="font-size: 8pt">
                                    <center><b>Checklist</B></CENTER><br>
                                    Nome
			do paciente ( ) –  Data Nasc.( ) –  RG( ) – N° carteira( )
			-- Validade da carteira( ) – Convênio( ) – Exame Solicitado(
			) 
                        Exame Autorizado( )             </FONT></FONT>
			</P>
			<P CLASS="western"><FONT FACE="Serif"><FONT SIZE=1 STYLE="font-size: 8pt">Médico
			Solicitante( ) – Assinatura Paciente ( )</FONT></FONT></P>
		</TD>
	</TR>
        </CENTER>
    </TABLE>
    <P CLASS="western" ALIGN=LEFT STYLE="margin-bottom: 0cm"><BR>
    </P>

</BODY>
</HTML>